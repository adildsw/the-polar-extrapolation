# -*- coding: utf-8 -*-
"""
Created on Mon Oct 15 19:18:32 2018

@author: anisha
"""


from flask import Flask, request
from flask_cors import CORS, cross_origin
from flask_restful import Resource, Api
from json import dumps
from flask_jsonpify import jsonify

app = Flask(__name__)
api = Api(app)

cors = CORS(app, resources={r"*": {"origins": "*"}})
api = Api(app)

@app.route("/1/", methods=['GET'])
def month1():

    import csv
    import json
    
    years, region, extent, area=[], [], [], [];
    
    dir_str='data/N_01_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    dir_str='data/S_01_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    total_data=[{"Year": y, "Region": r, "Extent": e, "Area": a} for y,r,e,a in zip(years, region, extent, area)]
    return dumps(total_data)

@app.route("/2/", methods=['GET'])
def month2():

    import csv
    import json
    
    years, region, extent, area=[], [], [], [];
    
    dir_str='data/N_02_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    dir_str='data/S_02_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    total_data=[{"Year": y, "Region": r, "Extent": e, "Area": a} for y,r,e,a in zip(years, region, extent, area)]
    return dumps(total_data)

@app.route("/3/", methods=['GET'])
def month3():

    import csv
    import json
    
    years, region, extent, area=[], [], [], [];
    
    dir_str='data/N_03_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    dir_str='data/S_03_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    total_data=[{"Year": y, "Region": r, "Extent": e, "Area": a} for y,r,e,a in zip(years, region, extent, area)]
    return dumps(total_data)

@app.route("/4/", methods=['GET'])
def month4():

    import csv
    import json
    
    years, region, extent, area=[], [], [], [];
    
    dir_str='data/N_04_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    dir_str='data/S_04_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    total_data=[{"Year": y, "Region": r, "Extent": e, "Area": a} for y,r,e,a in zip(years, region, extent, area)]
    return dumps(total_data)

@app.route("/5/", methods=['GET'])
def month5():

    import csv
    import json
    
    years, region, extent, area=[], [], [], [];
    
    dir_str='data/N_05_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    dir_str='data/S_05_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    total_data=[{"Year": y, "Region": r, "Extent": e, "Area": a} for y,r,e,a in zip(years, region, extent, area)]
    return dumps(total_data)

@app.route("/6/", methods=['GET'])
def month6():

    import csv
    import json
    
    years, region, extent, area=[], [], [], [];
    
    dir_str='data/N_06_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    dir_str='data/S_06_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    total_data=[{"Year": y, "Region": r, "Extent": e, "Area": a} for y,r,e,a in zip(years, region, extent, area)]
    return dumps(total_data)

@app.route("/7/", methods=['GET'])
def month7():

    import csv
    import json
    
    years, region, extent, area=[], [], [], [];
    
    dir_str='data/N_07_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    dir_str='data/S_07_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    total_data=[{"Year": y, "Region": r, "Extent": e, "Area": a} for y,r,e,a in zip(years, region, extent, area)]
    return dumps(total_data)

@app.route("/8/", methods=['GET'])
def month8():

    import csv
    import json
    
    years, region, extent, area=[], [], [], [];
    
    dir_str='data/N_08_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    dir_str='data/S_08_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    total_data=[{"Year": y, "Region": r, "Extent": e, "Area": a} for y,r,e,a in zip(years, region, extent, area)]
    return dumps(total_data)

@app.route("/9/", methods=['GET'])
def month9():

    import csv
    import json
    
    years, region, extent, area=[], [], [], [];
    
    dir_str='data/N_09_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    dir_str='data/S_09_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    total_data=[{"Year": y, "Region": r, "Extent": e, "Area": a} for y,r,e,a in zip(years, region, extent, area)]
    return dumps(total_data)

@app.route("/10/", methods=['GET'])
def month10():

    import csv
    import json
    
    years, region, extent, area=[], [], [], [];
    
    dir_str='data/N_10_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    dir_str='data/S_10_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    total_data=[{"Year": y, "Region": r, "Extent": e, "Area": a} for y,r,e,a in zip(years, region, extent, area)]
    return dumps(total_data)

@app.route("/11/", methods=['GET'])
def month11():

    import csv
    import json
    
    years, region, extent, area=[], [], [], [];
    
    dir_str='data/N_11_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    dir_str='data/S_11_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    total_data=[{"Year": y, "Region": r, "Extent": e, "Area": a} for y,r,e,a in zip(years, region, extent, area)]
    return dumps(total_data)

@app.route("/12/", methods=['GET'])
def month12():

    import csv
    import json
    
    years, region, extent, area=[], [], [], [];
    
    dir_str='data/N_12_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    dir_str='data/S_12_extent_v3.0.csv'
    csvfile = open(dir_str, 'r')
    fieldnames = ("year","mo","data-type","region","extent","area")
    reader = csv.DictReader( csvfile, fieldnames)
    for row in reader:
        years.append(row['year'])
        region.append(row['region'])
        extent.append(row['extent'])
        area.append(row['area'])
        
    total_data=[{"Year": y, "Region": r, "Extent": e, "Area": a} for y,r,e,a in zip(years, region, extent, area)]
    return dumps(total_data)

if __name__ == '__main__':
     app.run(port=5002)
    
